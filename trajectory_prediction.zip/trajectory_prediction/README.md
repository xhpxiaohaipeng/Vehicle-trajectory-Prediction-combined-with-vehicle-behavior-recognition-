#A trajectory Prediction LSTM Model combined with vehicle behavior recognition.
This code predicts the trajectory of the vehicle in the next 3 seconds.
1. Run the LSTM_behavior_prediction-8.ipynb file to train a behavior recognition model.
2. Running LSTM_Trajectory_prediction-8-behavior.ipynb and LSTM_Trajectory_prediction-8-nobehavior.ipynb, respectively makes a comparison of whether the vehicle behavior is considered or not.
3. The dataset is in the pickle file.
If you want to know more, please refer to my paper "UB-LSTM:A trajectory prediction method combined with vehicle behavior recognition".
